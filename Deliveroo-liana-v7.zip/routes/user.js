const P = require('bluebird');
const express = require('express');
const router = express.Router();
const Liana = require('forest-express-sequelize');
const models = require('../models');
var request = require('request');
// New Permissions Manager
const { PermissionMiddlewareCreator } = require('forest-express-sequelize');
const permissionMiddlewareCreator = new PermissionMiddlewareCreator('user');

const API_URL = process.env.API_URL;

router.post('/user/actions/invite', permissionMiddlewareCreator.smartAction(), async (req, res) => {
    const userId = req.body.data.attributes.ids[0];
    const user = await models.user.findByPk(userId);
    const userCognitoId = user.cognitoId;

    if (userCognitoId != null){
        res.status(400).send({ error: 'The user has already been sent an invite!' });
    } else {
        var options = {
          url: API_URL + '/admin/user/invite',
          headers: {
            'Secret-Key': process.env.SECRET_KEY
          },
          method: 'POST',
          form: JSON.stringify({'user_id': userId})
        };

        // request(options).then(res.send({
        //     success: "User has been invited. Please refresh the page."
        // }));
        // request is not promised based, but callback based
        request(options, (error, response, body) => {
          res.send({success: "User has been invited. Please refresh the page."});
        });        
    }
});

router.post('/user/actions/delete', Liana.ensureAuthenticated, async (req, res) => {
    const userId = req.body.data.attributes.ids[0];

    var options = {
      url: API_URL + '/admin/user/delete',
      headers: {
        'Secret-Key': process.env.SECRET_KEY
      },
      method: 'POST',
      form: JSON.stringify({'user_id': userId})
    };

    // request(options).then(res.send({
    //     success: "User has been deleted."
    // }));
	// request is not promised based, but callback based
	request(options, (error, response, body) => {
		res.send({success: "User has been deleted."});
	});    

});

module.exports = router;