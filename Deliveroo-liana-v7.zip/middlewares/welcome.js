const path = require('path');

module.exports = function welcome(app) {
  app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/index.html'));
  });
};
