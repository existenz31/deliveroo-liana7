const Liana = require('forest-express-sequelize');
const models = require('../models/');
const _ = require('lodash');

Liana.collection('user', {
  actions: [{
    name: 'Invite user',
    endpoint: '/forest/user/actions/invite',
    }]
});

Liana.collection('user', {
  actions: [{
    name: 'Master delete',
    endpoint: '/forest/user/actions/delete',
    }]
});
